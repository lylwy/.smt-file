#Author-
#Description-
import adsk.core, adsk.fusion, adsk.cam, traceback
import numpy as np
import json
import os
import shutil

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        product = app.activeProduct
        design = adsk.fusion.Design.cast(product)
       
        if not design:
            ui.messageBox('No activate Fusion design')
        temBRepMgr = adsk.fusion.TemporaryBRepManager.get()
        path = "C:/Users/25441/Desktop/j(1)"
        file_names = os.listdir(path=path)
        file_count = 0
        for file_name in file_names:
            file_count += 1
            print('file_name', file_name)
            print(file_count)
            file = f'{path}/{file_name}'
            tem = temBRepMgr.createFromFile(file)
            tem_body = tem.item(0)
            bodiescom = app.activeProduct
            importManager = app.importManager
            smtimportoptions = importManager.createSMTImportOptions(file)
            bodies = importManager.importToTarget2(smtimportoptions,bodiescom.rootComponent)
            bodies = bodies[0].bRepBodies
            properity_body = bodies.item(0)
            part_graph = dict()
            links = []
            nodes = []


            for face in tem_body.faces:
                part_face_graph = dict()
                face_id = face.tempId #face ID
                face_type = face.geometry.objectType #face type
                face_reversed = face.isParamReversed #facce reversed flag
                face_area = face.area #face area
                centroid_point = face.centroid # face center point
                point_on_face = face.pointOnFace 
                face_uvgrid_point=uvgrid(face=face, method='point') #point2D -> point3D
                face_uvgrid_normal=uvgrid(face=face, method='normal') #normal of point
                if face_type == 'adsk::core::Plane':
                    face_normal = face.geometry.normal
                    face_origin = face.geometry.origin
                elif face_type == 'adsk::core::Cylinder':
                    face_normal = face.geometry.axis
                    face_origin = face.geometry.origin
                    face_radius = face.geometry.radius
                elif face_type == 'adsk::core::Cone':
                    face_normal = face.geometry.axis
                    face_origin = face.geometry.origin
                    face_radius = face.geometry.radius
                elif face_type == 'adsk::core::Sphere':
                    face_normal = adsk.core.Point3D.create(0,0,1)
                    face_origin = face.geometry.origin
                    face_radius = face.geometry.radius
                elif face_type == 'adsk::core::Torus':
                    face_normal = face.geometry.axis
                    face_origin = face.geometry.origin
                elif face_type =='adsk::core::Eliipticalcylinder':
                    face_normal = face.geometry.axis
                    face_origin = face.geometry.origin
                    face_major_radius = face.geometry.majorRadius
                    face_minor_radius = face.geometry.minorRadius
                elif face_type == 'adsk::core::EllipticalCone':
                    face_normal = face.geometry.getAxes()
                    face_origin = face.geometry.origin
                    face_major_radius = face.geometry.majorRadius
                    face_minor_radius = face.geometry.minorRadius
                elif face_type == 'adsk::core::Nurbs':
                    face_info = 'break'
                part_face_graph["id"] = face_id
                part_face_graph["point"] = face_uvgrid_point
                part_face_graph["normal"] = face_uvgrid_normal
                part_face_graph["surface_type"] = face_type
                part_face_graph["reversed"] = face_reversed
                part_face_graph["area"] = face_area
                part_face_graph["centroid_x"] = centroid_point.x
                part_face_graph["centroid_y"] = centroid_point.y
                part_face_graph["centroid_z"] = centroid_point.z
                part_face_graph["normal_x"] = face_normal.x
                part_face_graph["normal_y"] = face_normal.y
                part_face_graph["normal_z"] = face_normal.z
                part_face_graph["origin_x"] = face_origin.x
                part_face_graph["origin_y"] = face_origin.y
                part_face_graph["origin_z"] = face_origin.z
                part_face_graph["point_on_face_x"] = point_on_face.x
                part_face_graph["point_on_face_y"] = point_on_face.y
                part_face_graph["point_on_face_z"] = point_on_face.z
                if face_type in ["adsk::core::Cylinder", "adsk::core::Cone", "adsk::core::Sphere"]:
                    part_face_graph["radius"] = face_radius
                nodes.append(part_face_graph)

            for edge in tem_body.edges:
                part_edge_graph = {}
                edge_id = edge.tempId
                edge_isdegenerate = edge.isDegenerate
                if edge_isdegenerate:
                    part_edge_graph["id"] = edge_id
                    part_edge_graph["is_degenerate"] = edge_isdegenerate
                    continue
                edge_type = edge.geometry.objectType
                edge_reversed = edge.isParamReversed
                edge_length = edge.length
                edge_ugrid_point = ugrid(edge=edge, method='point')
                edge_ugrid_tangent = ugrid(edge=edge, method='tangent')

                if edge_type == 'adsk::core::Line3D':
                    edge_center = edge.geometry.startPoint
                    edge_endpoint = edge.geometry.endPoint
                    edge_normal = edge.geometry.startPoint
                    edge_normal.x = edge_endpoint.x - edge_center.x
                    edge_normal.y = edge_endpoint.y - edge_center.y
                    edge_normal.y = edge_endpoint.z - edge_center.z

                elif edge_type == 'adsk::core::Arc3D':
                    edge_center = edge.geometry.center
                    edge_normal = edge.geometry.normal
                    edge_Radius = edge.geometry.radius

                elif edge_type == 'adsk::core::Circle3D':
                    edge_center = edge.geometry.center
                    edge_normal = edge.geometry.normal
                    edge_Radius = edge.geometry.radius
            
                elif edge_type == 'adsk::core::Ellipse3D':
                    edge_center = edge.geometry.center
                    edge_normal = edge.geometry.normal
                    # edge_Radius = edge.geometry.radius
            
                elif edge_type == 'adsk::core::EllipticalArc3D':
                    edge_center = edge.geometry.center
                    edge_normal = edge.geometry.normal
                    # edge_Radius = edge.geometry.radius
            
                part_edge_graph["id"] = edge_id
                part_edge_graph["is_degenerate"] = edge_isdegenerate
                part_edge_graph["point"] = edge_ugrid_point
                part_edge_graph["tangent"] = edge_ugrid_tangent
                part_edge_graph["curve_type"] = edge_type
                part_edge_graph["reversed"] = edge_reversed
                part_edge_graph["length"] = edge_length
                part_edge_graph["normal_x"] = edge_normal.x
                part_edge_graph["normal_y"] = edge_normal.y
                part_edge_graph["normal_z"] = edge_normal.z
                part_edge_graph["center_x"] = edge_center.x
                part_edge_graph["center_y"] = edge_center.y
                part_edge_graph["center_z"] = edge_center.z
                if edge_type in ["adsk::core::Arc3D", "adsk::core::Circle3D", "adsk::core::Ellipse3D", "adsk::core::EllipticalArc3D"]:
                    part_edge_graph["radius"] = edge_Radius
                nodes.append(part_edge_graph)
            for face in tem_body.faces:
                edge_num = face.edges
                edge_one = face.tempId
                for adj_id in range(edge_num.count):
                    edge_two = edge_num.item(adj_id).tempId
                    links_dict = dict()
                    links_dict["source"] = edge_one
                    links_dict["target"] = edge_two
                    links.append(links_dict)
            body_bounding_box_maxpoint = tem_body.boundingBox.maxPoint
            body_bounding_box_minpoint = tem_body.boundingBox.minPoint
            body_vertex_count = tem_body.vertices.count
            body_edge_count = tem_body.edges.count
            body_face_count = tem_body.faces.count
            body_shell_count = tem_body.shells.count
            body_area = tem_body.area
            body_volume = tem_body.volume
            body_PhysicalProperties = properity_body.getPhysicalProperties(adsk.fusion.CalculationAccuracy.MediumCalculationAccuracy)
            body_density = body_PhysicalProperties.density
            body_mass = body_PhysicalProperties.mass
            body_center_of_mass = body_PhysicalProperties.centerOfMass
            body_PrincipalAxes = body_PhysicalProperties.getPrincipalAxes()
            body_XYZMomentsOfInertia = body_PhysicalProperties.getXYZMomentsOfInertia()
            properties = dict()
            properties= {"bounding_bodx":{
                              "type":tem_body.boundingBox.objectType,
                         "max_point":{
                              "type":tem_body.boundingBox.maxPoint.objectType,
                                 "x":body_bounding_box_maxpoint.x,
                                 "y":body_bounding_box_maxpoint.y,
                                 "z":body_bounding_box_maxpoint.z
                          },
                         "min_point":{
                               "type":tem_body.boundingBox.maxPoint.objectType,
                                  "x":body_bounding_box_minpoint.x,
                                  "y":body_bounding_box_minpoint.y,
                                  "z":body_bounding_box_minpoint.z
                          }
                       }
                    }  
            properties["vertex_count"] = body_vertex_count
            properties["edge_count"] = body_edge_count
            properties["face_count"] = body_face_count
            properties["shell_count"] = body_shell_count
            properties["area"] = body_area
            properties["volume"] = body_volume
            properties["density"] = body_density
            properties["mass"] = body_mass
            properties["center_of_mass"] = {"type":body_center_of_mass.objectType,
                                           "x":body_center_of_mass.x,
                                           "y":body_center_of_mass.y,
                                           "z":body_center_of_mass.z} 
            properties["principal_axes"] = {"x_axis":{"type":body_PrincipalAxes[1].objectType,
                                                     "x":body_PrincipalAxes[1].x,
                                                     "y":body_PrincipalAxes[1].y,
                                                     "z":body_PrincipalAxes[1].z,
                                                "length":body_PrincipalAxes[1].length
                                                 },
                                        "y_axis":{"type":body_PrincipalAxes[2].objectType,
                                                     "x":body_PrincipalAxes[2].x,
                                                     "y":body_PrincipalAxes[2].y,
                                                     "z":body_PrincipalAxes[2].z,
                                                "length":body_PrincipalAxes[2].length
                                                     },
                                        "z_axis":{"type":body_PrincipalAxes[3].objectType,
                                                     "x":body_PrincipalAxes[3].x,
                                                     "y":body_PrincipalAxes[3].y,
                                                     "z":body_PrincipalAxes[3].z,
                                                "length":body_PrincipalAxes[3].length
                                                    }
                                       }
            properties["xyz_moments_of_inertia"] = {"xx":body_XYZMomentsOfInertia[1],
                                                "yy":body_XYZMomentsOfInertia[2],
                                                "zz":body_XYZMomentsOfInertia[3],
                                                "xy":body_XYZMomentsOfInertia[4],
                                                "yz":body_XYZMomentsOfInertia[5],
                                                "xz":body_XYZMomentsOfInertia[6]}
            part_graph["directed"] = False
            part_graph["multigraph"] = False
            part_graph["graph"] = {}
            part_graph["nodes"] = nodes
            part_graph["links"] = links
            part_graph["properties"] = properties
            save_file_path=f'C:\\Users\\25441\\Desktop\\smt2json'
            file_name_front, extension = os.path.splitext(file_name)
            extension = '.json'
            save_file_name = f'{file_name_front}.json'
            save_file = os.path.join(save_file_path, save_file_name)
            data = json.dumps(part_graph, indent=1)
            with open(save_file,'w',newline='\n') as file_obj:
                file_obj.write(data)
            for close in bodies:
                body_close= close.parentComponent.parentDesign.parentDocument
                body_close.close(False)
            print("success")
    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

def uvgrid(face, num_u = 10, num_v = 10, method=None):

    assert num_u >= 2
    assert num_v >= 2
    eval = face.evaluator
    face_para_bounding = eval.parametricRange()  #2D bounding box 
    point_max = face_para_bounding.maxPoint # maxpoint of 2Dbounding box
    point_min = face_para_bounding.minPoint # minpoint of 2Dbounding box
    umax = point_max.x
    vmax = point_max.y
    umin = point_min.x
    vmin = point_min.y
    bounding_bodx_2d = []
    u_intervals = [umin, umax] #u axis
    v_intervals = [vmin, vmax] #v axis
    bounding_bodx_2d.append(u_intervals)
    bounding_bodx_2d.append(v_intervals)
    uvg = []
    uv_values = np.zeros((num_u, num_v, 2), dtype=np.float32) #init uv_value

    for i in range(num_u):
        u = interpolate(bounding_bodx_2d[0], float(i)/(num_u-1)) #Uniform split u-axis
        for j in range(num_v):
            v = interpolate(bounding_bodx_2d[1], float(j)/(num_v-1)) #Uniform split v-axis
            uv = np.array([u, v])
            uv_values[i, j] = uv
            face_point2D = adsk.core.Point2D.create(u,v)   #np -> point2D
            val = fn_face(uv=face_point2D, method=method, eval=eval) #return 3D point or normal of 2Dpoint
            uvg.append(val.x)
            uvg.append(val.y)
            uvg.append(val.z)
    uv_grid = uvg
    return uv_grid

def ugrid(edge, num_u = 10, method=None):

    assert num_u >= 2
    edge_eval = edge.evaluator
    edge_para_bounding = edge_eval.getParameterExtents()
    pointmax = edge_para_bounding[2]
    pointmin = edge_para_bounding[1]
    bounding_box_2D = []
    u_interval = [pointmin, pointmax]
    bounding_box_2D.append(u_interval)
    ug = []
    u_values = np.zeros((num_u), dtype=np.float32)
    for i in range(num_u):
        u = interpolate(bounding_box_2D[0], float(i)/(num_u-1))
        # u = np.array([u], dtype=np.double)
        u_values[i] = u
        val = fn_edge(u=u, method=method, eval=edge_eval)
        ug.append(val.x)
        ug.append(val.y)
        ug.append(val.z)
    u_grid = ug
    return u_grid

def interpolate(intervals, t):
    assert intervals[0] < intervals[1]
    return (1.0 - t)*intervals[0] + t*intervals[1]  

def fn_face(uv, method, eval):
    if method == 'point':
        _, point = eval.getPointAtParameter(uv)
        return point
    elif method == 'normal':
        _, normal = eval.getNormalAtParameter(uv)
        return normal

def fn_edge(u, method, eval):
    if method == 'point':
        _, point = eval.getPointAtParameter(u)
        return point
    elif method == 'tangent':
        _, tangent = eval.getTangent(u)
        return tangent